module lab5ex3 (
    input  wire clk,
    input  wire S1, S2,
    output wire X, Y,
    output wire [3:0] leds, 
    output reg  buzzer = 1'b1
);

reg [7:0] x = 80, y = 60;
reg [9:0] sx = 0, sy = 0;
reg [10:0] timer = 0;
reg [3:0] phase = 0;        // 0=N, 1=I, 2=C, 3=O, 4=Star, 5=M, 6=A, 7=R, 8=I, 9=A, 10=Heart
reg [3:0] segment = 0;
reg [6:0] t = 0;

reg s1a = 1, s1b = 1;
reg s2a = 1, s2b = 1;

reg [18:0] db1 = 0, db2 = 0;
reg k1 = 1, k2 = 1;
reg prev1 = 1, prev2 = 1;

reg [13:0] tone_count = 0;
reg [21:0] beep_count = 0;

function [31:0] shape;
    input [3:0] p;
    input [3:0] s;
    begin
        shape = {8'd80,8'd60,8'd80,8'd60}; // Default safe shape
        case (p)
        // 0: N
        0: case(s)
            0: shape={8'd80,8'd60,8'd80,8'd210};
            1: shape={8'd80,8'd210,8'd160,8'd60};
            2: shape={8'd160,8'd60,8'd160,8'd210};
        endcase
        // 1: I
        1: case(s)
            0: shape={8'd100,8'd210,8'd140,8'd210};
            1: shape={8'd120,8'd210,8'd120,8'd60};
            2: shape={8'd100,8'd60,8'd140,8'd60};
        endcase
        // 2: C
        2: case(s)
            0: shape={8'd160,8'd210,8'd80,8'd210};
            1: shape={8'd80,8'd210,8'd80,8'd60};
            2: shape={8'd80,8'd60,8'd160,8'd60};
        endcase
        // 3: O
        3: case(s)
            0: shape={8'd80,8'd210,8'd80,8'd60};
            1: shape={8'd80,8'd60,8'd160,8'd60};
            2: shape={8'd160,8'd60,8'd160,8'd210};
            3: shape={8'd160,8'd210,8'd80,8'd210};
        endcase
        // 4: Star
        4: case(s)
            0: shape={8'd120,8'd210,8'd155,8'd75};
            1: shape={8'd155,8'd75,8'd70,8'd155};
            2: shape={8'd70,8'd155,8'd170,8'd155};
            3: shape={8'd170,8'd155,8'd85,8'd75};
            4: shape={8'd85,8'd75,8'd120,8'd210};
        endcase
        // 5: M
        5: case(s)
            0: shape={8'd80,8'd60,8'd80,8'd210};
            1: shape={8'd80,8'd210,8'd120,8'd135};
            2: shape={8'd120,8'd135,8'd160,8'd210};
            3: shape={8'd160,8'd210,8'd160,8'd60};
        endcase
        // 6: A
        6: case(s)
            0: shape={8'd80,8'd60,8'd120,8'd210};
            1: shape={8'd120,8'd210,8'd160,8'd60};
            2: shape={8'd95,8'd115,8'd145,8'd115};
        endcase
        // 7: R
        7: case(s)
            0: shape={8'd80,8'd60,8'd80,8'd210};
            1: shape={8'd80,8'd210,8'd140,8'd210};
            2: shape={8'd140,8'd210,8'd160,8'd185};
            3: shape={8'd160,8'd185,8'd140,8'd160};
            4: shape={8'd140,8'd160,8'd80,8'd160};
            5: shape={8'd110,8'd160,8'd160,8'd60};
        endcase
        // 8: I
        8: case(s)
            0: shape={8'd100,8'd210,8'd140,8'd210};
            1: shape={8'd120,8'd210,8'd120,8'd60};
            2: shape={8'd100,8'd60,8'd140,8'd60};
        endcase
        // 9: A
        9: case(s)
            0: shape={8'd80,8'd60,8'd120,8'd210};
            1: shape={8'd120,8'd210,8'd160,8'd60};
            2: shape={8'd95,8'd115,8'd145,8'd115};
        endcase
        // 10: Heart
        10: case(s)
            0: shape={8'd128,8'd55,8'd92,8'd95};
            1: shape={8'd92,8'd95,8'd72,8'd140};
            2: shape={8'd72,8'd140,8'd88,8'd180};
            3: shape={8'd88,8'd180,8'd112,8'd195};
            4: shape={8'd112,8'd195,8'd128,8'd175};
            5: shape={8'd128,8'd175,8'd144,8'd195};
            6: shape={8'd144,8'd195,8'd168,8'd180};
            7: shape={8'd168,8'd180,8'd184,8'd140};
            8: shape={8'd184,8'd140,8'd164,8'd95};
            9: shape={8'd164,8'd95,8'd128,8'd55};
        endcase
        endcase
    end
endfunction

reg [3:0] last_segment;
always @(*) begin
    case (phase)
        0: last_segment = 2; // N
        1: last_segment = 2; // I
        2: last_segment = 2; // C
        3: last_segment = 3; // O
        4: last_segment = 4; // Star
        5: last_segment = 3; // M
        6: last_segment = 2; // A
        7: last_segment = 5; // R
        8: last_segment = 2; // I
        9: last_segment = 2; // A
        10: last_segment = 9; // Heart
        default: last_segment = 0;
    endcase
end

wire [31:0] v = shape(phase, segment);
wire [7:0] x0 = v[31:24];
wire [7:0] y0 = v[23:16];
wire [7:0] x1 = v[15:8];
wire [7:0] y1 = v[7:0];

wire signed [10:0] dx =
    $signed({1'b0,x1}) - $signed({1'b0,x0});
wire signed [10:0] dy =
    $signed({1'b0,y1}) - $signed({1'b0,y0});
wire signed [20:0] ix =
    $signed({1'b0,x0}) +
    (dx * $signed({1'b0,t})) / 63;
wire signed [20:0] iy =
    $signed({1'b0,y0}) +
    (dy * $signed({1'b0,t})) / 63;

wire press1 = prev1 && !k1;
wire press2 = prev2 && !k2;

always @(posedge clk) begin
    // Synchronize buttons
    s1a <= S1;
    s1b <= s1a;
    s2a <= S2;
    s2b <= s2a;

    // Debounce: approximately 10 ms
    if (s1b == k1)
        db1 <= 0;
    else if (db1 == 499999) begin
        db1 <= 0;
        k1 <= s1b;
    end else
        db1 <= db1 + 1'b1;

    if (s2b == k2)
        db2 <= 0;
    else if (db2 == 499999) begin
        db2 <= 0;
        k2 <= s2b;
    end else
        db2 <= db2 + 1'b1;

    prev1 <= k1;
    prev2 <= k2;

    // Working sigma-delta DAC
    sx <= {2'b00,sx[7:0]} + {2'b00,x};
    sy <= {2'b00,sy[7:0]} + {2'b00,y};

    // Button selection
    if (press1 || press2) begin
        if (press1)
            phase <= (phase == 10) ? 0 : phase + 1'b1;
        else
            phase <= (phase == 0) ? 10 : phase - 1'b1;

        segment <= 0;
        t <= 0;
        timer <= 0;

        // Start beep
        beep_count <= 4000000;
        tone_count <= 0;
        buzzer <= 1'b1;
    end else begin
        // Drawing engine
        if (timer == 1388) begin
            timer <= 0;
            x <= ix[7:0];
            y <= iy[7:0];
            if (t == 63) begin
                t <= 0;
                segment <= (segment == last_segment) ?
                           0 : segment + 1'b1;
            end else
                t <= t + 1'b1;
        end else
            timer <= timer + 1'b1;

        // Buzzer oscillator
        if (beep_count != 0) begin
            beep_count <= beep_count - 1'b1;
            if (tone_count == 12499) begin
                tone_count <= 0;
                buzzer <= ~buzzer;
            end else
                tone_count <= tone_count + 1'b1;
        end else begin
            // Inactive buzzer = HIGH
            buzzer <= 1'b1;
            tone_count <= 0;
        end
    end
end

// LED shifting logic: phase[1:0] mathematically cycles 0, 1, 2, 3 as the phase increases.
// 4'b0001 << 0 = 0001 (LED 1)
// 4'b0001 << 1 = 0010 (LED 2)
// 4'b0001 << 2 = 0100 (LED 3)
// 4'b0001 << 3 = 1000 (LED 4)
assign leds = 4'b0001 << (phase[1:0]);

assign X = sx[8];
assign Y = sy[8];
endmodule