module lab3ex2(input clk, key1,
            output reg [7:0] seg,
            output [3:0] dig);

reg [3:0] n = 0;
reg old = 1;

assign dig = 4'b1110;   

always @(posedge clk) begin
    old <= key1;
    if (old & ~key1) n <= (n==9) ? 0 : n+1;
end

always @*
case(n)
  0: seg = 8'hC0;   1: seg = 8'hF9;
  2: seg = 8'hA4;   3: seg = 8'hB0;
  4: seg = 8'h99;   5: seg = 8'h92;
  6: seg = 8'h82;   7: seg = 8'hF8;
  8: seg = 8'h80;   9: seg = 8'h90;
endcase

endmodule