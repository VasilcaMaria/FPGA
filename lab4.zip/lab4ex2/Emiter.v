module Emiter (
    input wire clk,                  // 50 MHz
    output wire rf_out
);
    // Original 1 MHz RF Carrier Generation
    reg [4:0] rf_count = 0;
    reg carrier = 0;

    always @(posedge clk) begin
        if (rf_count == 24) begin
            rf_count <= 0;
            carrier <= ~carrier;
        end else begin 
            rf_count <= rf_count + 1;
        end
    end


    reg [19:0] melody [0:31];
    initial begin
        // Twinkle Twinkle Little Star
        // C, C, G, G, A, A, G (Hold/Rest)
        melody[0]  = 20'd95555; // C4
        melody[1]  = 20'd95555; // C4
        melody[2]  = 20'd63776; // G4
        melody[3]  = 20'd63776; // G4
        melody[4]  = 20'd56818; // A4
        melody[5]  = 20'd56818; // A4
        melody[6]  = 20'd63776; // G4
        melody[7]  = 20'd0;     // Rest to separate phrases
        
        // F, F, E, E, D, D, C (Hold/Rest)
        melody[8]  = 20'd71586; // F4
        melody[9]  = 20'd71586; // F4
        melody[10] = 20'd75843; // E4
        melody[11] = 20'd75843; // E4
        melody[12] = 20'd85132; // D4
        melody[13] = 20'd85132; // D4
        melody[14] = 20'd95555; // C4
        melody[15] = 20'd0;     // Rest
        
        // G, G, F, F, E, E, D (Hold/Rest)
        melody[16] = 20'd63776; // G4
        melody[17] = 20'd63776; // G4
        melody[18] = 20'd71586; // F4
        melody[19] = 20'd71586; // F4
        melody[20] = 20'd75843; // E4
        melody[21] = 20'd75843; // E4
        melody[22] = 20'd85132; // D4
        melody[23] = 20'd0;     // Rest
        
        // C, C, G, G, A, A, G (Hold/Rest) - Return to main theme
        melody[24] = 20'd95555; // C4
        melody[25] = 20'd95555; // C4
        melody[26] = 20'd63776; // G4
        melody[27] = 20'd63776; // G4
        melody[28] = 20'd56818; // A4
        melody[29] = 20'd56818; // A4
        melody[30] = 20'd63776; // G4
        melody[31] = 20'd0;     // Rest
    end

    // Tempo Timer: Controls the duration of each note in the sequence
    // 50 MHz * 0.4s = 20,000,000 clocks per rhythmic step (moderate tempo)
    reg [24:0] note_timer = 0;
    reg [4:0] note_index = 0;

    always @(posedge clk) begin
        if (note_timer == 19999999) begin
            note_timer <= 0;
            note_index <= note_index + 1;
        end else begin
            note_timer <= note_timer + 1;
        end
    end

    // Audio Tone Generator
    reg [19:0] audio_count = 0;
    reg audio = 0;
    wire [19:0] current_divider = melody[note_index];

    always @(posedge clk) begin
        if (current_divider == 0) begin
            audio_count <= 0;
            audio <= 0; // Output silence for rests
        end else if (audio_count >= current_divider) begin
            audio_count <= 0;
            audio <= ~audio;
        end else begin
            audio_count <= audio_count + 1;
        end
    end

    // Modulatie ON/OFF (OOK)
    assign rf_out = carrier & audio; 
endmodule